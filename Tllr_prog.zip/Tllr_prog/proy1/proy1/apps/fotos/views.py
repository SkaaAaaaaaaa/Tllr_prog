from django.shortcuts import render
from .models import Mifoto

# Create your views here.
def fotos (request):
    mis_fotos = Mifoto.objects.all()
    return render(request, "fotos.html",{"fotos":mis_fotos})
