from django.contrib import admin
from.models import Mifoto

admin.site.register(Mifoto)

# Register your models here.
