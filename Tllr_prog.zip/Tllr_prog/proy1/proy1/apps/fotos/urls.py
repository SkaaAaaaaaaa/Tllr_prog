from django.urls import path
from . import views

urlpatterns = [
    path("fotos",views.fotos, name ="fotos"), 
]